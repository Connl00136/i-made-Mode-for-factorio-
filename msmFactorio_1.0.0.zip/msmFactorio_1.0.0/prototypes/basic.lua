local util = util
local base_furnace = table.deepcopy(data.raw["furnace"]["stone-furnace"])

data:extend({
  {
    type = "item",
    name = "msm-stud-furnace",
    icon = "__msmFactorio__/graphics/stud-furnace-i.png",
    icon_size = 32,
    subgroup = "smelting-machine",
    order = "z[msm-stud-furnace]",
    place_result = "msm-stud-furnace",
    stack_size = 50
  },
  {
    type = "furnace",
    name = "msm-stud-furnace",
    icon = "__msmFactorio__/graphics/stud-furnace-i.png",
    icon_size = 32,
    flags = {"placeable-neutral", "placeable-player", "player-creation"},
    minable = {mining_time = 0.2, result = "msm-stud-furnace"},
    max_health = 2000,
    corpse = base_furnace.corpse,
    dying_explosion = base_furnace.dying_explosion,
    collision_box = base_furnace.collision_box,
    selection_box = base_furnace.selection_box,
    drawing_box = base_furnace.drawing_box,
    source_inventory_size = 1,
    result_inventory_size = 1,
    crafting_categories = {"smelting"},
    crafting_speed = 2,
    energy_usage = "90kW",
    energy_source = {
      type = "burner",
      fuel_categories = {"chemical"},
      effectivity = 2,
      fuel_inventory_size = 2,
      burnt_inventory_size = 1,
      emissions_per_minute = { pollution = 2 }
    },
    animation = base_furnace.animation,
    working_visualisations = base_furnace.working_visualisations,
    vehicle_impact_sound = base_furnace.vehicle_impact_sound,
    open_sound = base_furnace.open_sound,
    close_sound = base_furnace.close_sound,
    working_sound = base_furnace.working_sound,
    fast_replaceable_group = "furnace"
  },
  {
    type = "recipe",
    name = "msm-stud-furnace",
    enabled = true,
    ingredients = {
      {type = "item", name = "stone", amount = 1},
      {type = "item", name = "wood", amount = 1}
    },
    results = { {type = "item", name = "msm-stud-furnace", amount = 1} }
  },
  {
    type = "item",
    name = "msm-solar-panel",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "z[msm-solar-panel]",
    place_result = "msm-solar-panel",
    stack_size = 50
  },
  {
    type = "solar-panel",
    name = "msm-solar-panel",
    icon = "__base__/graphics/icons/solar-panel.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 0.2, result = "msm-solar-panel"},
    max_health = 200,
    fast_replaceable_group = "solar-panel",
    energy_source = { type = "electric", usage_priority = "solar" },
    production = "60000000kW",
    picture = table.deepcopy(data.raw["solar-panel"]["solar-panel"].picture)
  },
  {
    type = "recipe",
    name = "msm-solar-panel",
    enabled = true,
    ingredients = { {type = "item", name = "iron-plate", amount = 1} },
    results = { {type = "item", name = "msm-solar-panel", amount = 1} }
  },
  {
    type = "item",
    name = "msm-accumulator",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "energy",
    order = "z[msm-accumulator]",
    place_result = "msm-accumulator",
    stack_size = 50
  },
  {
    type = "accumulator",
    name = "msm-accumulator",
    icon = "__base__/graphics/icons/accumulator.png",
    icon_size = 64, icon_mipmaps = 4,
    flags = {"placeable-neutral", "player-creation"},
    minable = {mining_time = 0.2, result = "msm-accumulator"},
    max_health = 300,
    fast_replaceable_group = "accumulator",
    energy_source = {
      type = "electric",
      buffer_capacity = "50000000000J",
      usage_priority = "tertiary",
      input_flow_limit = "50000000000W",
      output_flow_limit = "50000000000W"
    },
    picture = table.deepcopy(data.raw["accumulator"]["accumulator"].picture)
  },
  {
    type = "recipe",
    name = "msm-accumulator",
    enabled = true,
    ingredients = { {type = "item", name = "iron-plate", amount = 1} },
    results = { {type = "item", name = "msm-accumulator", amount = 1} }
  }
})
