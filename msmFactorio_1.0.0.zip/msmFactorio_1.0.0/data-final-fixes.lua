local overlay_icon = "__msmFactorio__/graphics/x150.png"

local function copy_icons(obj)
  if obj.icons then
    local t = table.deepcopy(obj.icons)
    table.insert(t, {icon = overlay_icon, icon_size = 64, scale = 0.25, shift = {8, 8}})
    return t
  elseif obj.icon then
    return {
      {icon = obj.icon, icon_size = obj.icon_size or 64, icon_mipmaps = obj.icon_mipmaps},
      {icon = overlay_icon, icon_size = 64, scale = 0.25, shift = {8, 8}}
    }
  end
  return { {icon = overlay_icon, icon_size = 64} }
end

local function only_item_results(results)
  if not results or type(results) ~= "table" then return false end
  for _,r in pairs(results) do
    local t = r.type or "item"
    if t ~= "item" then return false end
  end
  return true
end

local function normalize_results(proto)
  if proto.results and type(proto.results)=="table" then return table.deepcopy(proto.results) end
  if proto.result then
    return {{type="item", name=proto.result, amount=proto.result_count or 1}}
  end
  return nil
end

local function normalize_ingredients(proto)
  if proto.ingredients and type(proto.ingredients)=="table" then
    local ing = {}
    for _,i in pairs(proto.ingredients) do
      if i[1] then
        table.insert(ing, {type="item", name=i[1], amount=i[2]})
      elseif i.name then
        table.insert(ing, table.deepcopy(i))
      end
    end
    return ing
  end
  return nil
end

local allow_cat = { ["smelting"]=true, ["crafting"]=true, ["advanced-crafting"]=true, ["crafting-with-fluid"]=true }
local function category_allowed(cat)
  if cat == nil then return true end
  return allow_cat[cat] == true
end
local item_types = {
  "item","ammo","capsule","gun","tool","armor","repair-tool","item-with-entity-data",
  "item-with-label","item-with-inventory","rail-planner","module","spidertron-remote"
}
local function get_item_prototype(name)
  for _,t in pairs(item_types) do
    if data.raw[t] and data.raw[t][name] then return data.raw[t][name] end
  end
  return nil
end
local function is_stackable_item(name)
  local proto = get_item_prototype(name)
  if not proto then return false end
  if proto.stackable == false then return false end
  if proto.stack_size and proto.stack_size <= 1 then return false end
  return true
end


for name, r in pairs(data.raw.recipe) do
  if string.find(name, "__x150$") then goto continue end
  local cat = r.category
  if not category_allowed(cat) then goto continue end

  local results = normalize_results(r)
  local ingredients = normalize_ingredients(r)
  if not results or not ingredients then goto continue end
  if not only_item_results(results) then goto continue end
  for _,res in pairs(results) do
    local name = res.name or res[1]
    if not is_stackable_item(name) then goto continue end
  end

  local results150 = {}
  for _,res in pairs(results) do
    local new = table.deepcopy(res)
    if new.amount then
      new.amount = (new.amount or 1) * 150
    elseif new.amount_min and new.amount_max then
      new.amount_min = math.floor(new.amount_min * 150)
      new.amount_max = math.floor(new.amount_max * 150)
    elseif new[2] then
      new[2] = new[2] * 150
    else
      new.amount = 150
    end
    table.insert(results150, new)
  end

  local new = {
    type = "recipe",
    name = name .. "__x150",
    localised_name = {"", (r.localised_name or {"recipe-name."..name, name}), {"recipe-name.msm-x150-suffix"}},
    category = r.category,
    subgroup = r.subgroup,
    order = (r.order or "") .. "~x",
    icons = copy_icons(r),
    energy_required = 0.2,
    ingredients = ingredients,
    results = results150,
    enabled = true,
    allow_as_intermediate = true,
    allow_decomposition = false
  }
  data:extend({new})
  ::continue::
end
